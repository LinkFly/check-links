{include shared-links.md}

{set-property html yes}
{set-property author "Gary Warren King"}
{set-property title "LIFT - the LIsp Framework for Testing"}

  [user-guide]: user-guide.html
  [Overview]: overview.html
  [FAQ]: faq.html

  [tarball]: http://common-lisp.net/project/lift/lift_latest.tar.gz
  [lift-changelog]: changelog.html
  [lift-cliki]: http://www.cliki.net/lift
  [lift-mailing-list]: http://common-lisp.net/cgi-bin/mailman/listinfo/lift-devel
  [lift-email]: mailto:lift-devel@common-lisp.net
  
  [SUnit]: http://www.sunit.com/
  [JUnit]: http://www.junit.com/
  
