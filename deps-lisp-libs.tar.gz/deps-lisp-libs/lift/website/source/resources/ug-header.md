{include shared-header.md}

{set-property style-sheets 
  "user-guide.css"
  "http://common-lisp.net/project/cl-containers/shared/style-200.css"}

<div id="header">
	<span class="logo"><a href="http://www.metabang.com/" title="metabang.com"><img src="http://common-lisp.net/project/cl-containers/shared/metabang-2.png" title="metabang.com" width="100" alt="Metabang Logo" /></a></span>

## LIFT

#### Fighting like cats with AK-47s

</div>
