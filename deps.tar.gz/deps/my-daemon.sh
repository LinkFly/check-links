sbcl --noinform --no-userinit --no-sysinit --load sbclrc-for-daemon.lisp --load my-restas-daemon.lisp my-daemon.conf $1
